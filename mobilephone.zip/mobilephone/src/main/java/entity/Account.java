package entity;

public class Account {
	private int id;
	private String username;
	private String sdt;
	private String email;
	private String password;
	
	public Account() {
		// TODO Auto-generated constructor stub
	}
	public Account(int id, String username,String password, String sdt, String email) {
		this.id = id;
		this.username = username;
		this.email = email;
		this.password = password;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getSdt() {
		return sdt;
	}
	public void setSdt(String sdt) {
		this.sdt = sdt;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	@Override
	public String toString() {
		return "Account [id=" + id + ", username=" + username + ", sdt=" + sdt + ", email=" + email + ", password="
				+ password + "]";
	}
	
}
