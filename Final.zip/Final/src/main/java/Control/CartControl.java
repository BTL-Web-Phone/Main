package Control;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.taglibs.standard.tag.rt.fmt.RequestEncodingTag;

import DAO.CartDAO;
import DAO.DAO;
import Entity.Cart;
import Entity.Product;

/**
 * Servlet implementation class CartControl
 */
@WebServlet(name="CartControl",urlPatterns="/Cart")
public class CartControl extends HttpServlet {
	private static final long serialVersionUID = 1L;


    public CartControl() {
        // TODO Auto-generated constructor stub
    }
    @SuppressWarnings("unused")
	protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        // Lấy dữ liệu từ DAO
        CartDAO dao = new CartDAO();
        DAO d = new DAO();
        String action = request.getParameter("action");
        HttpSession session = request.getSession(true);
        
        CartDAO shop = (CartDAO) session.getAttribute("SHOP");
        if (action.equals("add-To-Cart")) {
	        if (shop == null) {
				shop = new CartDAO();
			}
	        int id = Integer.parseInt(request.getParameter("getId"));
	        
	        Product p = d.getProductById(id);
	        
	        Cart c = new Cart(p);
	        shop.addProduct(c);
	        session.setAttribute("SHOP",shop);
	        request.getRequestDispatcher("index.jsp").forward(request, response);
        }
        else if (action.equals("AddMore")) {
			request.getRequestDispatcher("index.jsp").forward(request, response);
		}
        else if (action.equals("Remove")) {
			String[] list = request.getParameterValues("Remove");
			if (list == null) {				
				if(session==null)
				{
					for(int i = 0;i<list.length;i++)
					{
						shop.remove(list[i]);
					}
					session.setAttribute("SHOP", shop);
				}
			}
			request.getRequestDispatcher("giohang.jsp").forward(request, response);
		}
        
    }

}
