package Control;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAO.DAO;
import Entity.Account;

/**
 * Servlet implementation class RegistControll
 */
@WebServlet(name = "regist", urlPatterns = { "/regist" })
public class RegistControll extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegistControll() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String username = request.getParameter("username");
		String email = request.getParameter("email");
		String sdt = request.getParameter("sdt");
		String password = request.getParameter("password");
		String check_password = request.getParameter("check_password");
		if(!password.equals(check_password)) {
			request.getRequestDispatcher("Regist.jsp").forward(request, response);
		}else {
			DAO dao = new DAO();
			Account a = dao.checkAccountExist(username);
			if(a == null) {
				dao.regist(username, password, sdt, email);;
				request.getRequestDispatcher("Login.jsp").forward(request, response);
			}else {
				request.getRequestDispatcher("Regist.jsp").forward(request, response);
			}
		}
	}
	

}
