/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

/**
 *
 * @author damtuananh
 */
public class Product {
    private int productID;
    private String image;
    private String productName;
    private String price;
    private String cost;
    
    public Product(){
    
    }

    public Product(int productID, String image, String productName, String price, String cost) {
        this.productID = productID;
        this.image = image;
        this.productName = productName;
        this.price = price;
        this.cost = cost;
    }

    public int getProductID() {
        return productID;
    }

    public void setProductID(int productID) {
        this.productID = productID;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getCost() {
        return cost;
    }

    public void setCost(String cost) {
        this.cost = cost;
    }

    // in dữ liệu
    @Override
    public String toString() {
        return "Product{" + "productID=" + productID + ", image=" + image + ", productName=" + productName + ", price=" + price + ", cost=" + cost + '}';
    }
    
    
}
