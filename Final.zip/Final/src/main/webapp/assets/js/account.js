const form = document.querySelector('#register-form');

form.addEventListener('submit', (event) => {

    event.preventDefault();

    // Lấy giá trị từ các trường biểu mẫu
    const usename = document.querySelector('#usename').value;
    const email = document.querySelector('#email').value;
    const sdt = document.querySelector('#sdt').value;
    const password = document.querySelector('#password').value;
    const check_password = document.querySelector('#check_password').value;

    // Kiểm tra xem các trường có rỗng hay không
    if (usename === '' || email === '' || password === '' || check_password === '') {
        alert('Vui lòng nhập thông tin');
        form.reset();
        return;
    }
    //kiểm tra tên người dùng
    const usenameRegex = /^[a-zA-Z]+(\s[a-zA-Z]+)*$/;

    if (!usenameRegex.test(usename)) {
        alert('Sai tên người dùng');
        form.reset();
        return;
    }
    const emailRegex = /^\w+@[a-z]+\.[a-z]{2,}$/;
    if(!emailRegex.test(email)){
        alert('Email không hợp lệ');
        form.reset();
        return;
    }
    const sdtRegex = /^\d{10}$/;
    if (!passwordRegex.test(password)) {
        alert('Mật khẩu gồm 10 chữ số');
        form.reset();
        return;
    }

    //kiểm tra mật khẩu (mặc định 8 chữ số)

    const passwordRegex = /^\d{8}$/;
    if (!passwordRegex.test(password)) {
        alert('Mật khẩu gồm 8 chữ số');
        form.reset();
        return;
    }

    //Kiểm tra lại mật khẩu
    if (check_password !== password) {
        alert('Mật khẩu nhập lại không khớp');
        form.reset();
        return;
    }

})