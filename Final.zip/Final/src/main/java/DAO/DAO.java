package DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import Context.DBContext;
import Entity.Account;
import Entity.Product;

public class DAO {
	Connection conn= null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	
    public List<Product> getAllProduct(){
        List<Product> list = new ArrayList<>();
        String query = "select * from product";
        try {
            conn = new DBContext().getConnection(); // mở kết nối với SQLServer
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while(rs.next()){
                list.add(new Product(rs.getInt(1), 
                                rs.getString(2), 
                            rs.getString(3), 
                                rs.getString(4), 
                                rs.getString(5)));
            }
        } catch (Exception e) {
        }
        
        return list;
    }
    public Product getProductById(int id){       
        String query = "select * from product where productId = ?";
        try {
            conn = new DBContext().getConnection(); // mở kết nối với SQLServer
            ps = conn.prepareStatement(query);
            ps.setInt(1, id);
            rs = ps.executeQuery();
            while(rs.next()){
                return new Product(rs.getInt(1), 
                                rs.getString(2), 
                            rs.getString(3), 
                                rs.getString(4), 
                                rs.getString(5));
            }
        } catch (Exception e) {
        }
        
        return null;
    }

    public List<Product> getAllProductIphone(){
        List<Product> list = new ArrayList<>();
        String query = "select * from product where productName like '%iphone%'";
        try {
            conn = new DBContext().getConnection(); // mở kết nối với SQLServer
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while(rs.next()){
                list.add(new Product(rs.getInt(1), 
                                rs.getString(2), 
                            rs.getString(3), 
                                rs.getString(4), 
                                rs.getString(5)));
            }
        } catch (Exception e) {
        }
        
        return list;
    }
    
    public List<Product> getAllProductOppo(){
        List<Product> list = new ArrayList<>();
        String query = "select * from product where productName like '%oppo%'";
        try {
            conn = new DBContext().getConnection(); // mở kết nối với SQLServer
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while(rs.next()){
                list.add(new Product(rs.getInt(1), 
                                rs.getString(2), 
                            rs.getString(3), 
                                rs.getString(4), 
                                rs.getString(5)));
            }
        } catch (Exception e) {
        }
        
        return list;
    }
    
    public List<Product> getAllProductSamsung(){
        List<Product> list = new ArrayList<>();
        String query = "select * from product where productName like '%samsung%'";
        try {
            conn = new DBContext().getConnection(); // mở kết nối với SQLServer
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while(rs.next()){
                list.add(new Product(rs.getInt(1), 
                                rs.getString(2), 
                            rs.getString(3), 
                                rs.getString(4), 
                                rs.getString(5)));
            }
        } catch (Exception e) {
        }
        
        return list;
    }
    
    public List<Product> getAllProductKhac(){
        List<Product> list = new ArrayList<>();
        String query = "select * from product where productName not like '%samsung%' and productName not like '%iphone%' and productName not like '%oppo%'";
        try {
            conn = new DBContext().getConnection(); // mở kết nối với SQLServer
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while(rs.next()){
                list.add(new Product(rs.getInt(1), 
                                rs.getString(2), 
                            rs.getString(3), 
                                rs.getString(4), 
                                rs.getString(5)));
            }
        } catch (Exception e) {
        }
        
        return list;
    }
    
    public void ThemSP(int productID, String image, String productName, String price, String cost) {
		String query = "insert into product(productID,image,productName,price,cost) values(?, ?, ?, ?, ?)";
		try {
			conn = new DBContext().getConnection();
			ps = conn.prepareStatement(query);
                        ps.setInt(1, productID);
			ps.setString(2, image);
			ps.setString(3, productName);
			ps.setString(4, price);
			ps.setString(5, cost);
			ps.executeUpdate();
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
    

   
    
    public static void main(String[] args) {
        DAO dao = new DAO();
        List<Product> list = dao.getAllProduct();
        for(Product i : list){
            System.out.println(i);
        }
    }
	
    public List<Product> searchByName(String txtSearch){
        List<Product> list = new ArrayList<>();
        String query = "select * from product where productName like ?";
        try {
            conn = new DBContext().getConnection(); // mở kết nối với SQLServer
            ps = conn.prepareStatement(query);
            ps.setString(1, "%"+txtSearch+"%");
            rs = ps.executeQuery();
            while(rs.next()){
                list.add(new Product(rs.getInt(1), 
                                rs.getString(2), 
                            rs.getString(3), 
                                rs.getString(4), 
                                rs.getString(5)));
            }
        } catch (Exception e) {
        }
        
        return list;
    }
    
    
	public Account login(String username, String password) {
		String query = "select * from account where username = ? and password = ?";
		
		try {
			conn = new DBContext().getConnection();
			ps = conn.prepareStatement(query);
			ps.setString(1, username);
			ps.setString(2, password);
			rs = ps.executeQuery();
			while(rs.next()) {
				return new Account(rs.getInt(1),
						rs.getString(2), 
						rs.getString(3), 
						rs.getString(4), 
						rs.getString(5),
                                                rs.getInt(6));
			}
		}catch (Exception e) {
			// TODO: handle exception
		}
		
		return null;
		
	}
	
	public Account checkAccountExist(String username) {
		String query = "select * from account where username = ? ";
		
		try {
			conn = new DBContext().getConnection();
			ps = conn.prepareStatement(query);
			ps.setString(1, username);
			rs = ps.executeQuery();
			while(rs.next()) {
				return new Account(rs.getInt(1),
						rs.getString(2), 
						rs.getString(3), 
						rs.getString(4), 
						rs.getString(5),
                                                rs.getInt(6));
			}
		}catch (Exception e) {
			// TODO: handle exception
		}
		
		return null;
		
	}
	public void regist(String username, String password, String sdt, String email) {
		String query = "insert into [user](username,sdt,email,password) values(?, ?, ?, ?)";
		try {
			conn = new DBContext().getConnection();
			ps = conn.prepareStatement(query);
			ps.setString(1, username);
			ps.setString(4, password);
			ps.setString(2, sdt);
			ps.setString(3, email);
			ps.executeUpdate();
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
}
