
const tab1 = document.querySelector('.tab-1');
const tab2 = document.querySelector('.tab-2');
const tab3 = document.querySelector('.tab-3');
const tabSP1 = document.querySelector('.tab-sp-1');
const tabSP2 = document.querySelector('.tab-sp-2');
const tabSP3 = document.querySelector('.tab-sp-3');
const tabIphone = document.querySelector('.tab-iphone');
const tabOppo = document.querySelector('.tab-oppo');
const tabSamsung = document.querySelector('.tab-samsung');
const tabKhac = document.querySelector('.tab-khac');
const tabSPIphone = document.querySelector('.tab-sp-iphone');
const tabSPOppo = document.querySelector('.tab-sp-oppo');
const tabSPSamsung = document.querySelector('.tab-sp-samsung');
const tabSPKhac = document.querySelector('.tab-sp-khac');


function showTab1() {
    tab1.classList.add('current');
    tab2.classList.remove('current');
    tab3.classList.remove('current');
    tabSP1.classList.add('color-0496fd');
    tabSP2.classList.remove('color-0496fd');
    tabSP3.classList.remove('color-0496fd');
}

function showTab2() {
    tab2.classList.add('current');
    tab1.classList.remove('current');
    tab3.classList.remove('current');
    tabSP2.classList.add('color-0496fd');
    tabSP1.classList.remove('color-0496fd');
    tabSP3.classList.remove('color-0496fd');
}

function showTab3() {
    tab3.classList.add('current');
    tab1.classList.remove('current');
    tab2.classList.remove('current');
    tabSP3.classList.add('color-0496fd');
    tabSP1.classList.remove('color-0496fd');
    tabSP2.classList.remove('color-0496fd');
}

tabSP1.addEventListener('click', showTab1);
tabSP2.addEventListener('click', showTab2);
tabSP3.addEventListener('click', showTab3);

function showTabIphone() {
    tabIphone.classList.add('current');
    tabOppo.classList.remove('current');
    tabSamsung.classList.remove('current');
    tabKhac.classList.remove('current');
    tabSPIphone.classList.add('color-0496fd');
    tabSPOppo.classList.remove('color-0496fd');
    tabSPSamsung.classList.remove('color-0496fd');
    tabSPKhac.classList.remove('color-0496fd');
}

function showTabOppo() {
    tabOppo.classList.add('current');
    tabIphone.classList.remove('current');
    tabSamsung.classList.remove('current');
    tabKhac.classList.remove('current');
    tabSPOppo.classList.add('color-0496fd');
    tabSPIphone.classList.remove('color-0496fd');
    tabSPSamsung.classList.remove('color-0496fd');
    tabSPKhac.classList.remove('color-0496fd');
}

function showTabSamsung() {
    tabSamsung.classList.add('current');
    tabIphone.classList.remove('current');
    tabOppo.classList.remove('current');
    tabKhac.classList.remove('current');
    tabSPSamsung.classList.add('color-0496fd');
    tabSPIphone.classList.remove('color-0496fd');
    tabSPOppo.classList.remove('color-0496fd');
    tabSPKhac.classList.remove('color-0496fd');
}

function showTabKhac() {
    tabKhac.classList.add('current');
    tabIphone.classList.remove('current');
    tabOppo.classList.remove('current');
    tabSamsung.classList.remove('current');
    tabSPKhac.classList.add('color-0496fd');
    tabSPIphone.classList.remove('color-0496fd');
    tabSPOppo.classList.remove('color-0496fd');
    tabSPSamsung.classList.remove('color-0496fd');
}

tabSPIphone.addEventListener('click',showTabIphone);
tabSPOppo.addEventListener('click',showTabOppo);
tabSPSamsung.addEventListener('click',showTabSamsung);
tabSPKhac.addEventListener('click',showTabKhac);


var slider = document.querySelector('.slider');
var index = 0;

setInterval(() => {
    if (index <= -300){
        index = 100;
    }
    index+=-100;
    slider.style.marginLeft = index + "%";
    console.log(index);
}, 10000);

function nextSlider() {
    if (index <= -300){
        index = 100;
    }
    index+=-100;
    slider.style.marginLeft = index + "%";
    console.log(index);
}

function backSlider() {
    if (index >= 0 ){
        index = -400;
    }
    index+=100;
    slider.style.marginLeft = index + "%";
    console.log(index);
}

const scrollContainer = document.querySelector('.swiper_brand');
const scrollContents = document.getElementsByClassName("tab_brand");

let isDragging = false;
let lastX;

Array.from(scrollContents).forEach(scrollContent => {
  scrollContent.addEventListener("mousedown", e => {
    isDragging = true;
    lastX = e.clientX;
    e.preventDefault();
  });

  document.addEventListener("mouseup", () => {
    isDragging = false;
  });

  scrollContainer.addEventListener("mousemove", e => {
    if (isDragging) {
      const diffX = e.clientX - lastX;
      scrollContainer.scrollLeft -= diffX;
      lastX = e.clientX;
    }
  });

  document.addEventListener("mouseleave", () => {
    isDragging = false;
  });
});



