package Entity;

public class Account {

    private int id;
    private String username;
    private String sdt;
    private String email;
    private String password;
    private int isAdmin;

    public Account() {
        // TODO Auto-generated constructor stub
    }

    public Account(int id, String username, String sdt, String email, String password, int isAdmin) {
        this.id = id;
        this.username = username;
        this.sdt = sdt;
        this.email = email;
        this.password = password;
        this.isAdmin = isAdmin;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getSdt() {
        return sdt;
    }

    public void setSdt(String sdt) {
        this.sdt = sdt;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getIsAdmin() {
        return isAdmin;
    }

    public void setIsAdmin(int isAdmin) {
        this.isAdmin = isAdmin;
    }

    @Override
    public String toString() {
        return "Account{" + "id=" + id + ", username=" + username + ", sdt=" + sdt + ", email=" + email + ", password=" + password + ", isAdmin=" + isAdmin + '}';
    }

}
