function nguoidung() {
    //kiem tra ho ten
    var hoten = document.formlh.ht.value;
    //kiem tra so dien thoai
    var dienthoai = document.formlh.sdt.value;
    var email = document.formlh.em.value;
    //kiểm tra họ tên

    
    if (!checkName(hoten)) {
        alert('Họ tên không phù hợp.',);
 
        return false;
    }
    //-------
    else if (!checkPhone(dienthoai)) {
        alert('Số điện thoại không phù hợp.');
        return false;
    }

    else if(!checkEmail(email)){
        alert('Email không đúng định dạng')
        return false;
    }

    alert('Gửi thành công. Chúng tôi chân thành cám ơn những góp ý từ bạn.'); // cám ơn
    // document.formlh.reset(); // làm sạch
    return false; // thoát
}

function checkName(str) {
    var special = '~!@#$%^&*()_+=-`./*{}[]|\'<>?;"';

    for (var i = 0; i < str.length; i++) {
        if (Number(str[i])) return false;
        for(var j = 0; j < special.length; j++)
            if (str[i] == special[j]) return false;
    }
    return true;
}

function checkPhone(phone) {
    for(var i =0 ; i< phone.length ;i++)
    {
        if(phone.charAt(i)<"0" || phone.charAt(i)>"9")
            return false;
    }
    return true;
}

function checkEmail(email){
    var ema = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/
    if(email.match(ema)) return true;
    return false;
}