package Control;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAO.DAO;
import Entity.Account;

/**
 * Servlet implementation class LoginControl
 */
@WebServlet(name = "login", urlPatterns = {"/login"})
public class LoginControl extends HttpServlet {

    private static final long serialVersionUID = 1L;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginControl() {
        super();
        // TODO Auto-generated constructor stub
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        DAO dao = new DAO();
        Account a = dao.login(username, password);
        if (a == null) {
            request.setAttribute("mess", "Sai Tên người dùng hoặc mật khẩu");
            request.getRequestDispatcher("Login.jsp").forward(request, response);

        } else {
            HttpSession session = request.getSession();
            session.setAttribute("acc", a);

            if (a.getIsAdmin() == 1) {
                response.sendRedirect("AdminControl");
            } else if (a.getIsAdmin() == 0) {
                response.sendRedirect("ProductControl");
            }
        }

    }

}
