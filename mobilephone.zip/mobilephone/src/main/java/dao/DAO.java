package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import context.DBContext;
import entity.Account;
import entity.Category;
import entity.Product;

public class DAO {
	Connection conn= null;
	PreparedStatement ps = null;
	ResultSet rs = null;
	
    public List<Product> getAllProduct(){
        List<Product> list = new ArrayList<>();
        String query = "select * from product";
        try {
            conn = new DBContext().getConnection(); // mở kết nối với SQLServer
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while(rs.next()){
                list.add(new Product(rs.getInt(1), 
                                rs.getString(2), 
                            rs.getString(3), 
                                rs.getString(4), 
                                rs.getString(5)));
            }
        } catch (Exception e) {
        }
        
        return list;
    }
    

    
    public List<Category> getAllCategory(){
        List<Category> listC = new ArrayList<>();
        String query = "select * from category";
        try {
            conn = new DBContext().getConnection(); // mở kết nối với SQLServer
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            while(rs.next()){
                listC.add(new Category(rs.getInt(1), 
                                rs.getString(2)));
            }
        } catch (Exception e) {
        }
        
        return listC;
    }
    
    public static void main(String[] args) {
        DAO dao = new DAO();
        List<Product> list = dao.getAllProduct();
        List<Category> listC = dao.getAllCategory();
        for(Product i : list){
            System.out.println(i);
        }
        for (Category o : listC) {
        	System.out.println(o);
        }
    }
	
    public List<Product> searchByName(String txtSearch){
        List<Product> list = new ArrayList<>();
        String query = "select * from product where productName like ?";
        try {
            conn = new DBContext().getConnection(); // mở kết nối với SQLServer
            ps = conn.prepareStatement(query);
            ps.setString(1, "%"+txtSearch+"%");
            rs = ps.executeQuery();
            while(rs.next()){
                list.add(new Product(rs.getInt(1), 
                                rs.getString(2), 
                            rs.getString(3), 
                                rs.getString(4), 
                                rs.getString(5)));
            }
        } catch (Exception e) {
        }
        
        return list;
    }
    
    
	public Account login(String username, String password) {
		String query = "select * from account where username = ? and password = ?";
		
		try {
			conn = new DBContext().getConnection();
			ps = conn.prepareStatement(query);
			ps.setString(1, username);
			ps.setString(2, password);
			rs = ps.executeQuery();
			while(rs.next()) {
				return new Account(rs.getInt(1),
						rs.getString(2), 
						rs.getString(3), 
						rs.getString(4), 
						rs.getString(5));
			}
		}catch (Exception e) {
			// TODO: handle exception
		}
		
		return null;
		
	}
	
	public Account checkAccountExist(String username) {
		String query = "select * from account where username = ? ";
		
		try {
			conn = new DBContext().getConnection();
			ps = conn.prepareStatement(query);
			ps.setString(1, username);
			rs = ps.executeQuery();
			while(rs.next()) {
				return new Account(rs.getInt(1),
						rs.getString(2), 
						rs.getString(3), 
						rs.getString(4), 
						rs.getString(5));
			}
		}catch (Exception e) {
			// TODO: handle exception
		}
		
		return null;
		
	}
	public void regist(String username, String password, String sdt, String email) {
		String query = "insert into account(`username`, `sdt`, `email`, `password`) values(?, ?, ?, ?)";
		try {
			conn = new DBContext().getConnection();
			ps = conn.prepareStatement(query);
			ps.setString(1, username);
			ps.setString(4, password);
			ps.setString(2, sdt);
			ps.setString(3, email);
			ps.executeUpdate();
		}catch (Exception e) {
			// TODO: handle exception
		}
	}
}
