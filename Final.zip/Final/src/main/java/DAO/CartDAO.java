package DAO;

import java.util.HashMap;

import Entity.Cart;

public class CartDAO extends HashMap{
	
	@SuppressWarnings("unchecked")
	public void addProduct(Cart cart) {
		int key = cart.getProduct().getProductID();
		if(this.containsKey(key))
		{
			int oldQuantity = ((Cart) this.get(key)).getQuantity();
			((Cart) this.get(key)).setQuantity(oldQuantity+1);
		}
		else {
			this.put(cart.getProduct().getProductID(), cart);
		}
	}
	
	public boolean deleteProduct(int id) {
		if(this.containsKey(id))
		{
			this.remove(id);
			return true;
		}
		else {
			return false;
		}
	}

}
